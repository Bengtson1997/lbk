from django.apps import AppConfig


class ProjektConfig(AppConfig):
    name = 'projekt'
